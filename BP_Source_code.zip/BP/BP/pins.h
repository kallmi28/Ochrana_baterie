/*
 * pins.h
 *
 * Created: 28-Apr-18 18:56:27
 *  Author: abc
 */ 


#ifndef PINS_H_
#define PINS_H_ 612f8gdhi12o8f2yuvig


#define D4 PD4
#define D5 PD5
#define D6 PD6
#define D7 PD7

#define EN PB6
#define RS PB7



#endif /* PINS_H_ */